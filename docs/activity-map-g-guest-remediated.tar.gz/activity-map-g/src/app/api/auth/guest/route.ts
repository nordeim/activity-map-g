import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { SESSION_COOKIE, sessionCookieOptions, signSession, verifySessionToken } from "@/lib/auth";
import { ensureGuestUser, sanitizeNextPath } from "@/lib/guest";

export const dynamic = "force-dynamic";

// Guest bootstrap (login-free first visit): the (app)/(bare) layouts redirect
// session-less visitors here; this handler provisions/uses the seeded guest
// account, signs the ordinary roam_session cookie (7-day TTL), and 303s back
// to the SANITISED next path (default "/" — see sanitizeNextPath for the
// open-redirect / loop guards, pinned by tests/guest.test.ts).
//
// Deliberately NOT rate-limited: there are no credentials to brute-force, and
// once the guest row exists the work is one indexed findUnique + one HMAC
// sign — the same order as any page render.

export async function GET(req: NextRequest) {
  const next = sanitizeNextPath(req.nextUrl.searchParams.get("next"));

  // An existing valid session (demo or guest) is never clobbered — hitting
  // the bootstrap while signed in just routes onward.
  if (verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value)) {
    return NextResponse.redirect(new URL(next, req.nextUrl.origin), 303);
  }

  const guest = await ensureGuestUser(db.user);
  const res = NextResponse.redirect(new URL(next, req.nextUrl.origin), 303);
  res.cookies.set(
    SESSION_COOKIE,
    signSession({ uid: guest.id, email: guest.email, name: guest.name }),
    sessionCookieOptions(),
  );
  return res;
}
