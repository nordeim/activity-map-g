# Deployment Guide

ROAM (Augsburg City Guide) ships as a single Next.js app with a SQLite file
database — one process, zero external services. This guide covers the
supported production paths and the environment contract.

## 1. Build

```bash
npm install
npm run build          # next build
```

The build compiles the page shell and the API route handlers. Prisma's
SQLite engine is kept external via `serverExternalPackages` in
`next.config.ts` so the query binary is not bundled away.

## 2. Run

```bash
npm run start          # NODE_ENV=production next start
```

The server listens on port 3000 by default (`PORT` overrides). Always start
it from the repo root via the npm script — the SQLite path resolution
(`file:../db/custom.db` → `<repo>/db/custom.db`) depends on the schema
anchor at `prisma/schema.prisma`. Behind a reverse proxy, forward
`X-Forwarded-Proto` so cookie attributes derive the right scheme. Session
cookies only get the `Secure` flag when `NEXT_PUBLIC_SITE_URL` is `https://`
(so HTTP previews and localhost keep working under `NODE_ENV=production`).

## 3. Environment variables

| Variable | Required | Purpose |
|----------|----------|---------|
| `DATABASE_URL` | Yes | SQLite connection string. See §4. |
| `AUTH_SECRET` | **Yes in production** | HMAC secret for session cookies. Generate with `openssl rand -hex 32`. An insecure dev constant is used when unset — never ship that. |
| `NEXT_PUBLIC_SITE_URL` | Recommended | Reserved canonical-origin slot (scaffold; not yet wired into app code). |

## 4. Database location (§4 — the `.env.example` reference)

`DATABASE_URL` accepts three forms:

1. **Relative `file:` URL (the default, zero-config local story).**
   ```
   DATABASE_URL="file:../db/custom.db"
   ```
   Relative URLs resolve against the **`prisma/` directory that owns
   `schema.prisma`** — exactly like the Prisma CLI — so this string points
   at `<repo>/db/custom.db` for `prisma db push`, `prisma/seed.ts`,
   `next build` and the running server alike, regardless of the process
   working directory. The resolution rule lives in
   `src/lib/db-path.ts` and is pinned by `tests/db-path.test.ts`.

2. **Absolute `file:` URL (recommended for production).**
   ```
   DATABASE_URL="file:/var/lib/roam/custom.db"
   ```
   Absolute paths pass through untouched — immune to any working-directory
   ambiguity across service managers, containers, or cron wrappers. Point
   them at a persisted volume and back the file up.

3. **PostgreSQL.** Switch `provider = "postgresql"` in
   `prisma/schema.prisma`, set a `postgresql://` URL, then
   `npm run db:push && npm run db:seed`.

Initialize (or reset) the database with:

```bash
npm run db:push        # apply schema (db push — no migrations folder)
npm run db:seed        # idempotent demo guide (wipes domain tables)
```

`db/*.db` is gitignored; every fresh clone recreates it from the two
commands above.

## 5. Updating

```bash
git pull
npm install
npx prisma generate    # after schema changes
npm run db:push
npm run build
# restart the server process
```

## 6. Verification checklist

```bash
curl -s https://your-host/api/health          # {"ok":true,"data":{"status":"healthy"}}
npm run lint && npm run typecheck && npm run test
./scripts/smoke-test.sh                       # 27 E2E checks (local)
npm run test:e2e                              # Playwright suite (local)
```

## 7. Common production issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| `Error code 14: Unable to open the database file` | Server started from a directory that has no `prisma/schema.prisma` and no absolute `DATABASE_URL` | Start via `npm run start`, or set an absolute `file:` URL (§4) |
| Logins loop back to `/login` | `AUTH_SECRET` changed between restarts | Keep the secret stable across restarts |
| Rate-limited logins (429) | 10 attempts/IP/15 min sliding window | Wait for `Retry-After`, or restart to clear the in-memory buckets (single-node) |
