Please carefully read completely and internalized your operating instructions in the attached/pasted text.
Now, please refresh your local workspace using `git pull` (or run `git clone https://github.com/nordeim/activity-map.git` if your local workspace has been reset), then meticulously review the included `AGENTS.md` , `CLAUDE.md` , `README.md` , `Project_Architecture_Document.md` and `activity-map_SKILL.md` to have a good understanding of the purpose of the project and its current codebase design and architecture. Next, meticulously plan to review the included `docs/session_25.md` , `docs/remediation-plan-session-25.md` , `worklog.md` , `docs/session_26.md` and `docs/start_server_log.txt` , then meticulously validate your deep understanding against the codebase to check for alignment to confirm the current project status. The repo included `skills/` folder is to be excluded from code checking, testing and compilation.

Next, please meticulously plan to iterate on the codebase to achieve visual and functional parity with `https://activity-map.base44.app/`  (need to login `https://activity-map.base44.app/login` using ID `sepnetflix2023@outlook.com` and password `$Abcd1234`). After you log in, you'll see a dashboard similar to the image `https://github.com/nordeim/activity-map/blob/main/docs/activity-map-dashboard.png`.
Use GitHub repo `https://github.com/nordeim/scandihaven.git` (review `AGENTS.md`, `CLAUDE.md`, `Project_Architecture_Document.md` and `scandihaven_SKILL.md` from repo `https://github.com/nordeim/scandihaven.git` for the tech stacks and model architecture) as the tech stack patterns. There are also skills in the `skills/` folder in the `https://github.com/nordeim/scandihaven.git` repo that may be relevant and helpful (refer to `https://github.com/nordeim/scandihaven/blob/main/skills/skills-catalog.md` to find relevant skills for help in building an awesome clone of `https://activity-map.base44.app/`).

The codebase has been deployed to live website at URL `https://activity-map.jesspete.shop/` . Please meticulously plan to run browser-based E2E tests to identify gaps and bugs/issues. Also check for visual fidelity/parity with the source site `https://activity-map.base44.app/`

Pay particular attention to compare the mobile navigation menu to ensure that the mobile menu is working as expected. Look out for possible TailwindCSS v4 related bug. The solution can be found in the Tailwind CSS v4 related skills in the repo `skill/` folder (check out the repo `skills/skills-catalog.md for the relevant skills for help). Also consider using `skills/clone-app-pat-pro`, `skills/agent-browser`, and `skills/tdd`.

Edit `.env` so that `DATABASE_URL="file:../db/custom.db"` - the `db/` folder should be placed at the root folder of the `activity-map` repo codebase. then change the relevant code files to reference the database in the right folder.

Add vitest and playwright test suite by modifying the respective config files in the repo.

Next, meticulously plan to create a comprehensive remediation plan with a detailed ToDo list to fix the identified codebase issues, bugs and gaps. Next, review and validate the remediation plan against the codebase again to ensure alignment before executing it meticulously. Use TDD approach to make code changes. Look for appropriate skills in the repo included `skills/` folder to help you in the planning (refer to the included `skills/skills-catalog.md` to look for suitable skills)

Capture some screenshots for the dev server running the remediated codebase, save the screen captures as image files under the `docs/screenshots/` folder in the new `activity-map` repo. Also, create a working `.env.example` that matches the codebase, include the `.env.example` in the git commit.

Next, update the relevant documentation to ensure alignment with the remediated codebase.

Finally, please `git commit` and then `git push` the root of the remediated codebase to my GitHub repo `git@github.com:nordeim/activity-map.git` using the ssh key below and wrapper script `https://github.com/nordeim/activity-map/blob/main/docs/ssh_git_wrapper_v3.py`.  refer to `https://github.com/nordeim/activity-map/blob/main/docs/how-to-git-push-using-ssh-wrapper_SKILL.md` for instruction to use ssh wrapper script for `git push`.

Do not create any new git branch. All git commits must be to the main branch.

SSH key for `git push`:
```

```
